# Advent calendar

This is a simple advent calendar made in textual
## WHAT DOES IT DO
- Simple advent calendar click on the days, if its before the days NO CLICKIE
- Stores what days were done in a txt file
- r TO reset