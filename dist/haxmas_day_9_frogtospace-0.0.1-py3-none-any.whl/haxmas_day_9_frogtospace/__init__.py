"""Advent Calendar app for Haxmas Day 9."""

from .main import main, AdventCalendarApp

__all__ = ["main", "AdventCalendarApp"]
__version__ = "0.0.1"
